import { MongoClient, type Db } from "mongodb"

let client: MongoClient
let db: Db

export async function getDatabase(): Promise<Db> {
  if (!process.env.MONGODB_URI) {
    throw new Error("MONGODB_URI environment variable is not set")
  }

  if (!client) {
    client = new MongoClient(process.env.MONGODB_URI)
    await client.connect()
  }

  if (!db) {
    db = client.db("aaladin-transcription")
  }

  return db
}

export async function closeDatabase() {
  if (client) {
    await client.close()
  }
}
