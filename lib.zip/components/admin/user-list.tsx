"use client"

import React, { useState, useEffect } from "react"
import { Eye, X } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"

interface User {
  id: string
  name: string
  email: string
  signupDate: string
  credits: number
}

interface TranscriptionHistory {
  id: string
  text: string
  type: "live" | "file"
  fileName?: string
  date: string
  language: string
  confidence?: number
}

interface UserHistoryModalProps {
  user: User | null
  isOpen: boolean
  onClose: () => void
}

const UserHistoryModal: React.FC<UserHistoryModalProps> = ({ user, isOpen, onClose }) => {
  const [history, setHistory] = useState<TranscriptionHistory[]>([])
  const { token } = useAuth()

  useEffect(() => {
    const fetchHistory = async () => {
      if (user && isOpen && token) {
        try {
          const res = await fetch(`/api/admin/users?userId=${user.id}`, {
            headers: { Authorization: `Bearer ${token}` },
          })
          if (res.ok) {
            const data = await res.json()
            setHistory(data.user.history)
          }
        } catch (e) {
          // handle error
        }
      }
    }
    fetchHistory()
  }, [user, isOpen, token])

  if (!isOpen || !user) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900/90 backdrop-blur-sm border border-violet-500/30 rounded-lg w-full max-w-4xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-violet-500/20">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">{user.name} - Transcription History</h2>
              <p className="text-gray-400 text-sm">{user.email}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-800 rounded-lg transition-colors">
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {history.length > 0 ? (
            <div className="space-y-4">
              {history.map((item) => (
                <div key={item.id} className="bg-gray-800/50 border border-violet-500/20 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="font-semibold text-white mb-1">{item.type === "live" ? "Live" : "File"} Transcription</div>
                      <div className="text-gray-300 text-sm mb-1">{item.text}</div>
                      {item.fileName && <div className="text-gray-400 text-xs">File: {item.fileName}</div>}
                      <div className="text-gray-400 text-xs">Language: {item.language}</div>
                      <div className="text-gray-400 text-xs">Confidence: {item.confidence}</div>
                      <div className="text-gray-400 text-xs">{new Date(item.date).toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-gray-400">No history found.</div>
          )}
        </div>
      </div>
    </div>
  )
}

const UserList: React.FC = () => {
  const { token } = useAuth()
  const [users, setUsers] = useState<User[]>([])
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  useEffect(() => {
    const fetchUsers = async () => {
      if (!token) return
      try {
        const res = await fetch("/api/admin/users", {
          headers: { Authorization: `Bearer ${token}` },
        })
        if (res.ok) {
          const data = await res.json()
          setUsers(data.users)
        }
      } catch (e) {
        // handle error
      }
    }
    fetchUsers()
  }, [token])

  const handleViewHistory = (user: User) => {
    setSelectedUser(user)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setSelectedUser(null)
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">User List</h1>
        <p className="text-gray-400">Manage users and view their activity</p>
      </div>

      <div className="bg-gray-900/50 backdrop-blur-sm border border-violet-500/30 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-800/50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Name</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Email</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Signup Date</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Credits</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700/50">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-800/30">
                  <td className="px-6 py-4 text-sm text-white font-medium">{user.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{user.email}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{new Date(user.signupDate).toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`font-medium ${
                        user.credits > 500 ? "text-green-400" : user.credits > 100 ? "text-yellow-400" : "text-red-400"
                      }`}
                    >
                      {user.credits}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleViewHistory(user)}
                      className="flex items-center gap-2 px-3 py-2 bg-violet-600 hover:bg-violet-700 text-white text-xs rounded-lg transition-colors"
                    >
                      <Eye className="w-3 h-3" />
                      View History
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {users.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No users found</p>
          </div>
        )}
      </div>

      <UserHistoryModal user={selectedUser} isOpen={isModalOpen} onClose={closeModal} />
    </div>
  )
}

export default UserList
