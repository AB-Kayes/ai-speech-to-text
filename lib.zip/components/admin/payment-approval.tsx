"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { Check, X, Clock } from "lucide-react"

interface PaymentRequest {
  id: string
  name: string
  email: string
  paymentMethod: string
  amount: number
  date: string
  status: "pending" | "approved" | "rejected"
}

interface Payment {
  id: string
  userId: string
  userName: string
  userEmail: string
  phoneNumber: string
  transactionId: string
  amount: number
  credits: number
  status: "pending" | "approved" | "rejected"
  createdAt: string
  approvedAt?: string
  approvedBy?: string
}
const PaymentApproval: React.FC = () => {
  const [payments, setPayments] = useState<PaymentRequest[]>([])

  useEffect(() => {
    // Mock data - in real app, fetch from API
    const mockPayments: PaymentRequest[] = [
      {
        id: "1",
        name: "John Doe",
        email: "john@example.com",
        paymentMethod: "Credit Card (**** 4242)",
        amount: 29.99,
        date: "2024-01-27 14:30:00",
        status: "pending",
      },
      {
        id: "2",
        name: "Jane Smith",
        email: "jane@example.com",
        paymentMethod: "PayPal",
        amount: 49.99,
        date: "2024-01-27 13:15:00",
        status: "pending",
      },
      {
        id: "3",
        name: "Bob Johnson",
        email: "bob@example.com",
        paymentMethod: "Credit Card (**** 5555)",
        amount: 19.99,
        date: "2024-01-27 12:45:00",
        status: "approved",
      },
    ]
    setPayments(mockPayments)
  }, [])

  const handleApprove = (id: string) => {
    setPayments((prev) =>
      prev.map((payment) => (payment.id === id ? { ...payment, status: "approved" as const } : payment)),
    )
  }

  const handleReject = (id: string) => {
    setPayments((prev) =>
      prev.map((payment) => (payment.id === id ? { ...payment, status: "rejected" as const } : payment)),
    )
  }

  const getStatusBadge = (status: PaymentRequest["status"]) => {
    switch (status) {
      case "pending":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-900/30 border border-yellow-500/50 rounded-full text-yellow-300 text-xs">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        )
      case "approved":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-900/30 border border-green-500/50 rounded-full text-green-300 text-xs">
            <Check className="w-3 h-3" />
            Approved
          </span>
        )
      case "rejected":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 bg-red-900/30 border border-red-500/50 rounded-full text-red-300 text-xs">
            <X className="w-3 h-3" />
            Rejected
          </span>
        )
    }
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Payment Approval</h1>
        <p className="text-gray-400">Review and approve pending payment requests</p>
      </div>

      <div className="bg-gray-900/50 backdrop-blur-sm border border-violet-500/30 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-800/50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Name</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Email</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Payment Method</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Amount</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Date</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Status</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700/50">
              {payments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-800/30">
                  <td className="px-6 py-4 text-sm text-white">{payment.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{payment.email}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{payment.paymentMethod}</td>
                  <td className="px-6 py-4 text-sm text-white font-medium">${payment.amount}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{new Date(payment.date).toLocaleString()}</td>
                  <td className="px-6 py-4">{getStatusBadge(payment.status)}</td>
                  <td className="px-6 py-4">
                    {payment.status === "pending" ? (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleApprove(payment.id)}
                          className="flex items-center gap-1 px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-xs rounded-lg transition-colors"
                        >
                          <Check className="w-3 h-3" />
                          Accept
                        </button>
                        <button
                          onClick={() => handleReject(payment.id)}
                          className="flex items-center gap-1 px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-xs rounded-lg transition-colors"
                        >
                          <X className="w-3 h-3" />
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span className="text-gray-500 text-xs">No actions</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {payments.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No payment requests found</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default PaymentApproval
