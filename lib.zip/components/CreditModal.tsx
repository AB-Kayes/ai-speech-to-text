"use client"

import type React from "react"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Smartphone, Zap } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"
import { toast } from "sonner"

interface CreditModalProps {
  isOpen: boolean
  onClose: () => void
}

const CreditModal: React.FC<CreditModalProps> = ({ isOpen, onClose }) => {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [phoneNumber, setPhoneNumber] = useState("")
  const [transactionId, setTransactionId] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { token } = useAuth()

  const creditPlans = [
    {
      id: "basic",
      name: "Basic Pack",
      credits: 1000,
      price: 100,
      description: "Perfect for light usage",
    },
    {
      id: "standard",
      name: "Standard Pack",
      credits: 2500,
      price: 200,
      description: "Great for regular users",
    },
    {
      id: "premium",
      name: "Premium Pack",
      credits: 5000,
      price: 350,
      description: "Best value for heavy users",
    },
  ]

  const handleSubmitPayment = async () => {
    if (!selectedPlan || !phoneNumber || !transactionId) {
      toast.error("Please fill in all fields")
      return
    }

    const plan = creditPlans.find((p) => p.id === selectedPlan)
    if (!plan) return

    setIsSubmitting(true)

    try {
      const response = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          phoneNumber,
          transactionId,
          amount: plan.price,
          credits: plan.credits,
        }),
      })

      if (response.ok) {
        toast.success("Payment submitted successfully! Awaiting admin approval.")
        setPhoneNumber("")
        setTransactionId("")
        setSelectedPlan(null)
        onClose()
      } else {
        const data = await response.json()
        toast.error(data.error || "Failed to submit payment")
      }
    } catch (error) {
      console.error("Payment submission error:", error)
      toast.error("Failed to submit payment")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Purchase Credits
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Credit Plans */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {creditPlans.map((plan) => (
              <Card
                key={plan.id}
                className={`cursor-pointer transition-all ${
                  selectedPlan === plan.id ? "ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-950" : "hover:shadow-md"
                }`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                <CardHeader className="text-center">
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {plan.credits.toLocaleString()} Credits
                  </div>
                  <div className="text-lg font-semibold mt-2">৳{plan.price}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {selectedPlan && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="h-5 w-5" />
                  Bkash Payment
                </CardTitle>
                <CardDescription>
                  Send money to: <strong>01XXXXXXXXX</strong> and provide the transaction details below
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phoneNumber">Your Bkash Phone Number</Label>
                  <Input
                    id="phoneNumber"
                    type="tel"
                    placeholder="01XXXXXXXXX"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="transactionId">Transaction ID</Label>
                  <Input
                    id="transactionId"
                    placeholder="Enter Bkash transaction ID"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                  />
                </div>

                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Payment Summary</h4>
                  <div className="flex justify-between">
                    <span>Credits:</span>
                    <span>{creditPlans.find((p) => p.id === selectedPlan)?.credits.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span>Total Amount:</span>
                    <span>৳{creditPlans.find((p) => p.id === selectedPlan)?.price}</span>
                  </div>
                </div>

                <Button onClick={handleSubmitPayment} disabled={isSubmitting} className="w-full">
                  {isSubmitting ? "Submitting..." : "Submit Payment"}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default CreditModal
