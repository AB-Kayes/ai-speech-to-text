"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { useAuth } from "./AuthContext"

interface HistoryItem {
  id: string
  text: string
  type: "live" | "file"
  fileName?: string
  language: string
  timestamp: string
  duration?: number
  confidence?: number
}

interface HistoryContextType {
  history: HistoryItem[]
  addHistoryItem: (item: Omit<HistoryItem, "id" | "timestamp">) => Promise<void>
  clearHistory: () => void
  isLoading: boolean
}

const HistoryContext = createContext<HistoryContextType | undefined>(undefined)

export const useHistory = () => {
  const context = useContext(HistoryContext)
  if (context === undefined) {
    throw new Error("useHistory must be used within a HistoryProvider")
  }
  return context
}

export const HistoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const { token, isAuthenticated } = useAuth()

  useEffect(() => {
    if (isAuthenticated && token) {
      fetchHistory()
    } else {
      setHistory([])
    }
  }, [isAuthenticated, token])

  const fetchHistory = async () => {
    if (!token) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/history", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setHistory(data.history)
      }
    } catch (error) {
      console.error("Error fetching history:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const addHistoryItem = async (item: Omit<HistoryItem, "id" | "timestamp">) => {
    if (!token) return

    try {
      const response = await fetch("/api/history", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(item),
      })

      if (response.ok) {
        const data = await response.json()
        const newItem: HistoryItem = {
          ...item,
          id: data.id,
          timestamp: new Date().toISOString(),
        }
        setHistory((prev) => [newItem, ...prev])
      }
    } catch (error) {
      console.error("Error saving history item:", error)
    }
  }

  const clearHistory = () => {
    setHistory([])
  }

  return (
    <HistoryContext.Provider
      value={{
        history,
        addHistoryItem,
        clearHistory,
        isLoading,
      }}
    >
      {children}
    </HistoryContext.Provider>
  )
}
