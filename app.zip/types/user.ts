export interface UserData {
  id: string
  email: string
  name: string
  credits: number
  plan: "free" | "premium" | "enterprise"
  status: "user" | "admin"
  createdAt: string
  lastLogin: string
}

export interface AuthState {
  user: UserData | null
  isAuthenticated: boolean
  isLoading: boolean
}
