"use client"

import Admin from "@/components/admin/Admin"

export default function AdminPage() {
  return <Admin />
}
